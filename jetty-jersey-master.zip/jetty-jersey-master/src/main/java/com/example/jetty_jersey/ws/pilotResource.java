package com.example.jetty_jersey.ws;


import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import com.example.jetty_jersy.dao.*;



@Path("/Pilot")
public class pilotResource {

	/*public static class Pilot {
		public static String tailNumber;
		public static String PilotType;
		public static int numOfSeats;
		public static List<String> previousFlights;
	}*/
	
	
	//List<Pilot> Pilots= new ArrayList<Pilot>();
	
	DAO pilot;
	/*private static DAO dao=null;
	public static DAO getInstance() {
		return PilotDAO.dao;
	}*/

/*	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/Pilot") //ce qu on ecrit dans le path est la fin de lappel //si {} on ecrit ce quon vet
	public List<Pilot> getPilot() {
		//List<Pilot> fleet= new ArrayList<Pilot>();
		List<Pilot> fleet= DAO.getInstance().getFleet();
		return fleet;
	}*/
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{id}")
	public List<Object> getDetailPilot(Pilot nom,Flight flt) {
		List<Object> fleet= new ArrayList<Object>();
		fleet.add(pilot.getPilotid(nom));
		fleet.add(pilot.getPilotName(nom));
		fleet.add(pilot.getPilotMail(nom));
		fleet.add(pilot.getPilotDescription(nom));
		fleet.add(pilot.getPlannedFlights(nom));
		fleet.add(pilot.postaflight(flt));
		return fleet;
	}

	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/Pilot")
	public Response retrievePilot(Pilot name) {
		System.out.println(pilot.getPilotid(name));
		return Response.ok().build();
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/{id}")
	public Response retrieveDetailPilot (Pilot name, Flight flt) { //ici jai mis pilot mais ca doit etre DAO....
		List<Object> fleet= new ArrayList<Object>();
		fleet.add(pilot.getPilotid(name));
		fleet.add(pilot.getPilotName(name));
		fleet.add(pilot.getPilotMail(name));
		fleet.add(pilot.getPilotDescription(name));
		fleet.add(pilot.getPlannedFlights(name));
		fleet.add(pilot.postaflight(flt));
		return Response.ok().build();
	}
	
	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/Pilot")
	public Response putPilot(Pilot name) {
		System.out.println(pilot.getPilotid(name));
		return Response.ok().build();
	}
	
	@DELETE 
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/Pilot")
	public void deleteExample(Pilot name) {
		name.Pilotid="";//remove id donc remove the Pilot
		System.out.println("this user was deleted");
	}

}
