package com.example.jetty_jersy.dao;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class Flight  {
	String airport;
	String direction;
	LocalDate date;
	LocalTime time;
	LocalTime Duration;
	int price;
	String flighttype;
	String appointment;
	int availableseats;
	String description;
	List<Passenger> passengers;
	Pilot pilot;
	
	
	
	
	
}
